package grammar_parser;

public interface Compilable {
    public String printConstructor();
}
