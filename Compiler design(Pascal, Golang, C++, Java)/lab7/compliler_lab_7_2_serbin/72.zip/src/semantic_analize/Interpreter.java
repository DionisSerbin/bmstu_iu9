package semantic_analize;

import syntax_analyze.ParseTree;

public abstract class Interpreter {

    public Interpreter(ParseTree parseTree)
    {

    }


}
